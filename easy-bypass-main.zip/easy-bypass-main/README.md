# EACBypass
EasyAntiCheat bypassing driver (29/07/2022)

KernelMode driver with some parts not included so no pasta!

### Includes
This driver includes a fully fledged EasyAntiCheat bypassing method of communication.

*Features*
  - Read memory
  - Write memory
  - Overwrite instructions with no-op
  - Draw Text
  - Draw Rectangle
  - Draw Filled Rectangle
  - Draw Line
  - Hooking API

**Communicates VIA function hook**

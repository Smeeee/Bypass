#pragma once
#include <ntddk.h>
#include <ntifs.h>
#include "hook.h"

// ur gay
